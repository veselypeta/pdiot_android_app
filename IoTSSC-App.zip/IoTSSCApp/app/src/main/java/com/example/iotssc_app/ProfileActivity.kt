package com.example.iotssc_app
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import com.example.iotssc_app.utils.Constants
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout

class ProfileActivity: BaseActivity() {

    lateinit var genderField: TextInputLayout
    lateinit var birthdayField: TextInputLayout
    lateinit var weightField: TextInputLayout
    lateinit var  heightField: TextInputLayout
    lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        genderField = findViewById(R.id.gender_input)
        birthdayField = findViewById(R.id.birthday_input)
        weightField = findViewById(R.id.weight_input)
        heightField = findViewById(R.id.height_input)
        saveButton = findViewById(R.id.save_profile)
        val items = listOf("Male", "Female")
        val adapter = ArrayAdapter(this, R.layout.lst_item, items)
        (genderField.editText as? AutoCompleteTextView)?.setAdapter(adapter)

        initialiseWithPreviousValues()

        saveButton.setOnClickListener {
            val bday = birthdayField.editText?.text.toString()
            val gender = genderField.editText?.text.toString()
            val weight = weightField.editText?.text.toString().toFloat()
            val height = heightField.editText?.text.toString().toFloat()

            val sharedPreferences = getSharedPreferences(Constants.PREFERENCES_FILE, Context.MODE_PRIVATE)
            sharedPreferences.edit().putString(Constants.PROFILE_BIRTHDAY, bday).apply()
            sharedPreferences.edit().putString(Constants.PROFILE_GENDER, gender).apply()
            sharedPreferences.edit().putFloat(Constants.PROFILE_WEIGHT, weight).apply()
            sharedPreferences.edit().putFloat(Constants.PROFILE_HEIGHT, height).apply()

            val contextView = findViewById<View>(R.id.profile_layout)
            Snackbar.make(contextView, "Profile Saved", Snackbar.LENGTH_SHORT)
                    .setAction("OK"){}.show()

        }

    }

    override fun getLayoutId(): Int {
        return  R.layout.activity_profile
    }

    override fun getBottomNavigationMenuItemId(): Int {
        return R.id.profile
    }

    private fun initialiseWithPreviousValues(){
        val sharedPreferences = getSharedPreferences(Constants.PREFERENCES_FILE, Context.MODE_PRIVATE)

        if (sharedPreferences.contains(Constants.PROFILE_HEIGHT)){
            heightField.editText?.setText(sharedPreferences.getFloat(Constants.PROFILE_HEIGHT, 0.0f).toString())
        }
        if (sharedPreferences.contains(Constants.PROFILE_GENDER)){
            (genderField.editText as AutoCompleteTextView).setText(sharedPreferences.getString(Constants.PROFILE_GENDER, ""), false)
        }
        if (sharedPreferences.contains(Constants.PROFILE_BIRTHDAY)){
            birthdayField.editText?.setText(sharedPreferences.getString(Constants.PROFILE_BIRTHDAY, ""))
        }
        if (sharedPreferences.contains(Constants.PROFILE_WEIGHT)){
            weightField.editText?.setText(sharedPreferences.getFloat(Constants.PROFILE_WEIGHT, 0.0f).toString())
        }
    }


}