package com.example.iotssc_app
import android.content.Context
import android.util.AttributeSet
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout

class JournalEntryComponent @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyle: Int = 0,
        defStyleRes: Int = 0
): ConstraintLayout(context, attrs, defStyle, defStyleRes) {

    var mTitle: TextView
    var mIcon: ImageView
    var mTime: TextView

    init {
        inflate(context, R.layout.journal_entry_layout, this)

        mTitle = findViewById(R.id.journal_entry_title)
        mIcon = findViewById(R.id.activity_icon)
        mTime = findViewById(R.id.journal_entry_time)
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.JournalEntryComponent)

        mTitle.text = attributes.getString(R.styleable.JournalEntryComponent_journal_entry_title)
        mIcon.setImageDrawable(attributes.getDrawable(R.styleable.JournalEntryComponent_journal_entry_icon))
        mTime.text = attributes.getString(R.styleable.JournalEntryComponent_journal_entry_time)

        attributes.recycle()
    }


}