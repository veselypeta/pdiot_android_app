package com.example.iotssc_app.Models
import java.lang.Exception
import java.util.*
import kotlin.collections.ArrayList

class ActivityPrediction(val activity: String, val value:Double){}
class SensorRecording(val accel_x: Long, val accel_y: Long, val accel_z: Long,
                      val gyro_x: Double, val gyro_y: Double, val gyro_z: Double){
    override fun toString(): String {
        return "[ $accel_x, $accel_y, $accel_z, $gyro_x, $gyro_y, $gyro_z ]"
    }
}

class FireStoreModel(data: Map<String, Any>){
    val resourceId: String = data["resourceId"] as String
    val created: Date = Date(data["created"] as Long)
    val activityPrediction: List<ActivityPrediction> = (data["activityPrediciton"] as ArrayList<Map<String, Any>>).map {
        a -> ActivityPrediction(a["label"] as String, getValueAsDouble(a["value"]))
    }

    val sensorData: List<SensorRecording> = (data["sensorData"] as ArrayList<Map<String, Any>>).map {
        r ->
            SensorRecording(r["accel_x"] as Long, r["accel_y"] as Long, r["accel_z"] as Long,
                    getValueAsDouble(r["gyro_x"]), getValueAsDouble(r["gyro_y"]), getValueAsDouble(r["gyro_z"]))
    }

    fun getPrediction(): Pair<String, Double>{
        var bestPredictionValue = Double.MIN_VALUE
        var bestPredictionLabel = ""

        for(a in activityPrediction){
            if (a.value > bestPredictionValue){
                bestPredictionLabel = a.activity
                bestPredictionValue = a.value
            }
        }
        return Pair(bestPredictionLabel, bestPredictionValue)
    }

    private fun getValueAsDouble(value : Any?) : Double{
        var v: Double
        try {
            v = value as Double
        } catch (e: Exception){
            v = (value as Long).toDouble()
        }
        return v
    }
}

