package com.example.iotssc_app

import android.os.Bundle
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.example.iotssc_app.Models.FireStoreModel
import com.example.iotssc_app.utils.Constants
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class JournalActivity: BaseActivity() {
    lateinit var layDynContainer: LinearLayout

    private val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        layDynContainer = findViewById(R.id.layDynContainer)

        Thread{
            fetchAndRenderActivityData()
        }.start()
    }
    override fun getLayoutId(): Int {
        return R.layout.activity_journal
    }

    override fun getBottomNavigationMenuItemId(): Int {
        return R.id.journal
    }

    private fun fetchAndRenderActivityData(){
        val colRef = db.collection(Constants.IOTSSC_FIREBASE_COLLECTION)

        colRef.orderBy("created", Query.Direction.DESCENDING).limit(20)
                .get()
                .addOnSuccessListener { result ->
                    for (document in result){
                        val fsModel = FireStoreModel(document.data)
                        addJournalEntry(fsModel.getPrediction().first, fsModel.created.toString(), getActivityIcon(fsModel.getPrediction().first))
                    }
                }
                .addOnFailureListener { exception ->
                    Log.d("Failure To Red", "Error getting document", exception)
                }
    }

    private fun getActivityIcon(activity:String): Int{
        return when (activity){
            "SITTING" -> R.drawable.ic_baseline_chair_24
            "LAYING" -> R.drawable.ic_baseline_bed_24
            "WALKING" -> R.drawable.ic_baseline_directions_walk_24
            "STANDING" -> R.drawable.ic_baseline_emoji_people_24
            "WALKING_UPSTAIRS" -> R.drawable.ic_baseline_stairs_24
            "WALKING_DOWNSTAIRS" -> R.drawable.ic_baseline_stairs_24
            else -> {
                R.drawable.ic_baseline_person_24
            }
        }
    }

    private fun addJournalEntry(activityTitle: String, activityTime: String, activityIcon: Int){
        val journalEntryComponent = JournalEntryComponent(this)
        journalEntryComponent.mTitle.text = activityTitle
        journalEntryComponent.mTime.text = activityTime
        journalEntryComponent.mIcon.setImageResource(activityIcon)
        layDynContainer.addView(journalEntryComponent)
    }
}