package com.example.iotssc_app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import com.firebase.ui.auth.AuthUI
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

abstract class BaseActivity : AppCompatActivity(), BottomNavigationView.OnNavigationItemSelectedListener {

    private lateinit var navigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Hide the title bar
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        supportActionBar?.hide()
        setContentView(getLayoutId())

        // check the authentication of the user
        checkCurrentUser()

        navigationView = findViewById(R.id.bottom_navigation)
        navigationView.setOnNavigationItemSelectedListener(this)
    }

    override fun onStart() {
        super.onStart()
        updateNavigationBarState()
    }

    override fun onPause() {
        super.onPause()
        overridePendingTransition(0, 0)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        Log.i("Base Activity","Reacting to item selected events")

        if (item.itemId == R.id.home_nav){
            // Start the Home Activity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        } else if (item.itemId == R.id.journal){
            // start journal activity
                Log.i("Base Activity", "Running Journal")
            val intent = Intent(this, JournalActivity::class.java)
            startActivity(intent)
        } else if (item.itemId == R.id.profile){
            // start profile activity
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        finish()

        return true
    }

    private fun updateNavigationBarState(){
        val actionId = getBottomNavigationMenuItemId()
        selectBottomNavigationBarItem(actionId)
    }

    private fun selectBottomNavigationBarItem(itemId : Int){
        val item = navigationView.menu.findItem(itemId)
        item.isChecked = true
    }

    private fun checkCurrentUser(){
        val user = Firebase.auth.currentUser
        if(user != null){
            Log.i("Main Activity", "User is signed in $user")
            // user is signed in
        } else {
            // no user is signed in
            Log.i("Main Activity", "User is not signed in")
            // launch the sign in intent
            createSignInIntent()
        }
    }

    private fun createSignInIntent() {
        val providers = arrayListOf(
                AuthUI.IdpConfig.GoogleBuilder().build()
        )

        startActivityForResult(
                AuthUI.getInstance()
                        .createSignInIntentBuilder()
                        .setAvailableProviders(providers)
                        .build(),
                RC_SIGN_IN
        )
    }

    abstract fun getLayoutId() : Int
    abstract fun getBottomNavigationMenuItemId(): Int

    companion object {

        private const val RC_SIGN_IN = 123
    }
}