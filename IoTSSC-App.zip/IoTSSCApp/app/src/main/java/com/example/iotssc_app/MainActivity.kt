package com.example.iotssc_app

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.example.iotssc_app.Models.FireStoreModel
import com.example.iotssc_app.Models.SensorRecording
import com.example.iotssc_app.utils.Constants
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.google.firebase.firestore.Query
import java.lang.Exception

class MainActivity : BaseActivity() {

    lateinit var testButton: Button
    lateinit var liveActivityText : TextView

    // axes of data
    lateinit var dataGraph: LineChart
    lateinit var accel_x:LineDataSet
    lateinit var accel_y:LineDataSet
    lateinit var accel_z:LineDataSet
    lateinit var allAccelData: LineData


    private val db = Firebase.firestore
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // find the UI Elements
        testButton = findViewById(R.id.test_button)
        liveActivityText = findViewById(R.id.live_acitivy)
        dataGraph = findViewById(R.id.data_graph)

        // setup buttons
        setupEventListener()
        // setup the graph
        setupGraph()
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun getBottomNavigationMenuItemId(): Int {
        return R.id.home_nav
    }

    private fun readFromDatabase(){

        val colRef = db.collection(Constants.IOTSSC_FIREBASE_COLLECTION);

        colRef.orderBy("created", Query.Direction.DESCENDING).limit(1)
            .get()
            .addOnSuccessListener { result ->
                for (document in result){
                    val fsModel = FireStoreModel(document.data)
                    Log.d("Date Created", "${fsModel.created}")
                }
            }
            .addOnFailureListener { exception ->
                Log.d("Failure To Red", "Error getting document", exception)
            }
    }

    private fun setupEventListener(){
        db.collection("iotssc")
                .orderBy("created", Query.Direction.DESCENDING)
                .limit(1)
                .addSnapshotListener { snapshots, e ->
            if (e != null) {
                Log.w("Event", "Listen Failed")
                return@addSnapshotListener
            }

            for (d in snapshots!!.documents){
                if (d.data != null){
                    try {
                        val fsModel = FireStoreModel(d.data!!)
                        val activity = fsModel.getPrediction()
                        liveActivityText.text = activity.first
                        updateGraph(fsModel.sensorData)
                        // TODO -- Update UI with new Data

                        Log.i("Event", "${fsModel.created}")
                    }catch (e: Exception){

                    }
                } else{
                    Log.i("Event", "Data Returned Null")
                }
            }
        }
    }

    private fun setupGraph(){
        val desc = Description()
        desc.text = "Accelerometer Data"
        desc.textSize = 28f
        dataGraph.description = desc

        val entries_x = ArrayList<Entry>()
        val entries_y = ArrayList<Entry>()
        val entries_z = ArrayList<Entry>()

        accel_x = LineDataSet(entries_x, "Accel X")
        accel_y = LineDataSet(entries_y, "Accel Y")
        accel_z = LineDataSet(entries_z, "Accel Z")


        accel_x.setDrawCircles(false)
        accel_y.setDrawCircles(false)
        accel_z.setDrawCircles(false)

        accel_x.setColor(
            ContextCompat.getColor(this,
                R.color.red
            ))
        accel_y.setColor(
            ContextCompat.getColor(this,
                R.color.green
            ))
        accel_z.setColor(
            ContextCompat.getColor(this,
                R.color.blue
            ))


        val dataSets = ArrayList<ILineDataSet>()
        dataSets.add(accel_x)
        dataSets.add(accel_y)
        dataSets.add(accel_z)

        allAccelData = LineData(dataSets)
        dataGraph.data = allAccelData
        dataGraph.invalidate()
    }

    private fun updateGraph(data: List<SensorRecording>){
//        val respeckData = mDelayRespeckQueue.take().getData()

        accel_x.clear()
        accel_y.clear()
        accel_z.clear()

        for ((i, r) in data.withIndex()){
            accel_x.addEntry(Entry(i.toFloat(), r.accel_x.toFloat()))
            accel_y.addEntry(Entry(i.toFloat(), r.accel_y.toFloat()))
            accel_z.addEntry(Entry(i.toFloat(), r.accel_z.toFloat()))
        }

        runOnUiThread {
            allAccelData.notifyDataChanged()
            dataGraph.notifyDataSetChanged()
            dataGraph.invalidate()
            dataGraph.setVisibleXRangeMaximum(150f)
            dataGraph.moveViewToX(dataGraph.lowestVisibleX + 40)
        }
    }

}