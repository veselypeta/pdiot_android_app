package com.example.iotssc_app.utils

object Constants {
    const val PREFERENCES_FILE = "com.example.iotssc_app.PREFERENCES_FILE_KEY"

    const val PROFILE_WEIGHT = "PROFILE_WEIGHT"
    const val PROFILE_HEIGHT = "PROFILE_HEIGHT"
    const val PROFILE_GENDER = "PROFILE_GENDER"
    const val PROFILE_BIRTHDAY = "PROFILE_BIRTHDAY"


    const val IOTSSC_FIREBASE_COLLECTION = "iotssc"
}