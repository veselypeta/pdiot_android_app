package com.example.iotssc_app

import android.content.Context
import android.util.AttributeSet
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout

class TitleComponent @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyle: Int = 0,
        defStyleRes: Int = 0
): ConstraintLayout(context, attrs, defStyle, defStyleRes) {

    var mTitle: TextView

    init {
        inflate(context, R.layout.title_layout, this)
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.TitleComponent)
        mTitle = findViewById(R.id.title)
        mTitle.text = attributes.getString(R.styleable.TitleComponent_title)
        attributes.recycle()
    }
}